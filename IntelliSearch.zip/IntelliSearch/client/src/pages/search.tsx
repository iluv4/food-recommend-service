import { useState } from "react";
import { useParams } from "wouter";
import Sidebar from "@/components/sidebar";
import SearchInterface from "@/components/search-interface";
import { Search } from "@shared/schema";

export default function SearchPage() {
  const { id } = useParams<{ id?: string }>();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [currentSearch, setCurrentSearch] = useState<Search | null>(null);

  return (
    <div className="flex min-h-screen bg-white">
      {/* Sidebar */}
      <Sidebar 
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        onSearchSelect={setCurrentSearch}
      />
      
      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <header className="bg-white border-b border-gray-200 p-4 lg:p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button 
                onClick={() => setSidebarOpen(true)}
                className="lg:hidden p-2 hover:bg-light-grey rounded-lg transition-colors"
              >
                <svg className="w-5 h-5 text-cool-grey" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                </svg>
              </button>
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-openai-green rounded-lg flex items-center justify-center">
                  <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                  </svg>
                </div>
                <h1 className="text-xl font-bold text-near-black" style={{ fontFamily: 'SF Pro Display, Inter, sans-serif' }}>
                  AI Search
                </h1>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="hidden md:flex items-center space-x-2 bg-light-grey px-3 py-1 rounded-full">
                <div className="w-2 h-2 bg-openai-green rounded-full"></div>
                <span className="text-sm text-cool-grey">GPT-4 Active</span>
              </div>
              <button className="p-2 hover:bg-light-grey rounded-lg transition-colors">
                <svg className="w-5 h-5 text-cool-grey" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </button>
            </div>
          </div>
        </header>

        {/* Search Interface */}
        <SearchInterface 
          currentSearch={currentSearch}
          onNewSearch={() => setCurrentSearch(null)}
        />
      </div>

      {/* Mobile Overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-20 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}
    </div>
  );
}
