import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Search } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";
import { cn } from "@/lib/utils";

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  onSearchSelect: (search: Search) => void;
}

export default function Sidebar({ isOpen, onClose, onSearchSelect }: SidebarProps) {
  const queryClient = useQueryClient();
  
  const { data: searches = [], isLoading } = useQuery<Search[]>({
    queryKey: ["/api/searches"],
  });

  const handleNewSearch = () => {
    onSearchSelect(null as any);
    onClose();
  };

  const handleSearchClick = (search: Search) => {
    onSearchSelect(search);
    onClose();
  };

  return (
    <div className={cn(
      "w-80 bg-light-grey border-r border-gray-200 flex flex-col transition-transform duration-300 lg:translate-x-0 fixed lg:relative z-30 h-full",
      isOpen ? "translate-x-0" : "-translate-x-full"
    )}>
      {/* Sidebar Header */}
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold text-near-black" style={{ fontFamily: 'SF Pro Display, Inter, sans-serif' }}>
            Search History
          </h2>
          <button 
            onClick={onClose}
            className="lg:hidden p-2 hover:bg-gray-200 rounded-lg transition-colors"
          >
            <svg className="w-5 h-5 text-cool-grey" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        <button 
          onClick={handleNewSearch}
          className="w-full mt-4 bg-openai-green text-white py-2 px-4 rounded-lg hover:bg-green-600 transition-colors font-medium"
        >
          <svg className="w-4 h-4 mr-2 inline-block" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
          </svg>
          New Search
        </button>
      </div>
      
      {/* Search History List */}
      <div className="flex-1 overflow-y-auto p-4 space-y-2">
        {isLoading ? (
          <div className="animate-pulse space-y-2">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="p-3 bg-gray-200 rounded-lg h-16"></div>
            ))}
          </div>
        ) : searches.length === 0 ? (
          <div className="text-center text-cool-grey py-8">
            <svg className="w-8 h-8 mx-auto mb-2 text-cool-grey" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
            <p className="text-sm">No searches yet</p>
            <p className="text-xs">Start a new search to see your history</p>
          </div>
        ) : (
          searches.map((search) => (
            <button
              key={search.id}
              onClick={() => handleSearchClick(search)}
              className="w-full p-3 hover:bg-white rounded-lg cursor-pointer transition-colors group text-left"
            >
              <div className="text-sm font-medium text-near-black mb-1 line-clamp-2">
                {search.query}
              </div>
              <div className="text-xs text-cool-grey">
                {formatDistanceToNow(new Date(search.createdAt), { addSuffix: true })}
              </div>
            </button>
          ))
        )}
      </div>
      
      {/* Sidebar Footer */}
      <div className="p-4 border-t border-gray-200">
        <div className="flex items-center space-x-3 p-3 hover:bg-white rounded-lg cursor-pointer transition-colors">
          <div className="w-8 h-8 bg-openai-green rounded-full flex items-center justify-center text-white text-sm font-medium">
            AI
          </div>
          <div className="flex-1">
            <div className="text-sm font-medium">AI Search</div>
            <div className="text-xs text-cool-grey">Powered by GPT-4</div>
          </div>
          <svg className="w-4 h-4 text-cool-grey hover:text-near-black transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
          </svg>
        </div>
      </div>
    </div>
  );
}
