import { useState, useRef, useEffect } from "react";
import { Search } from "@shared/schema";
import SearchResults from "@/components/search-results";
import { useSearch } from "@/hooks/use-search";

interface SearchInterfaceProps {
  currentSearch: Search | null;
  onNewSearch: () => void;
}

const examplePrompts = [
  {
    icon: "💡",
    title: "Explain a complex concept",
    description: "Break down quantum computing in simple terms"
  },
  {
    icon: "💻",
    title: "Help with coding", 
    description: "Review my JavaScript function for optimization"
  },
  {
    icon: "📊",
    title: "Analyze data",
    description: "What trends do you see in this dataset?"
  },
  {
    icon: "✍️",
    title: "Creative writing",
    description: "Write a short story about time travel"
  }
];

export default function SearchInterface({ currentSearch, onNewSearch }: SearchInterfaceProps) {
  const [query, setQuery] = useState("");
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const { searchMutation, isLoading } = useSearch();

  const handleSubmit = async (searchQuery?: string) => {
    const finalQuery = searchQuery || query;
    if (!finalQuery.trim()) return;
    
    await searchMutation.mutateAsync({ query: finalQuery });
    setQuery("");
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setQuery(e.target.value);
    
    // Auto-resize textarea
    const textarea = e.target;
    textarea.style.height = "auto";
    textarea.style.height = Math.min(textarea.scrollHeight, 128) + "px";
  };

  const handleExampleClick = (description: string) => {
    handleSubmit(description);
  };

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
    }
  }, [currentSearch]);

  const showWelcome = !currentSearch && !isLoading && !searchMutation.data;
  const showResults = currentSearch || searchMutation.data;

  return (
    <main className="flex-1 flex flex-col">
      {/* Welcome State */}
      {showWelcome && (
        <div className="flex-1 flex flex-col items-center justify-center p-6 max-w-4xl mx-auto w-full">
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-openai-green rounded-2xl flex items-center justify-center mx-auto mb-4">
              <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
              </svg>
            </div>
            <h2 className="text-3xl font-bold text-near-black mb-2" style={{ fontFamily: 'SF Pro Display, Inter, sans-serif' }}>
              How can I help you today?
            </h2>
            <p className="text-cool-grey text-lg">Ask me anything and get intelligent, AI-powered responses</p>
          </div>

          {/* Example Prompts */}
          <div className="grid md:grid-cols-2 gap-4 w-full max-w-2xl mb-8">
            {examplePrompts.map((prompt, index) => (
              <button
                key={index}
                onClick={() => handleExampleClick(prompt.description)}
                className="p-4 border border-gray-200 rounded-xl hover:border-openai-green hover:bg-light-grey transition-all text-left group"
              >
                <div className="flex items-start space-x-3">
                  <span className="text-xl">{prompt.icon}</span>
                  <div>
                    <div className="font-medium text-near-black mb-1">{prompt.title}</div>
                    <div className="text-sm text-cool-grey">{prompt.description}</div>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Search Results */}
      {showResults && (
        <SearchResults 
          search={currentSearch || searchMutation.data} 
          isLoading={isLoading}
        />
      )}

      {/* Loading State */}
      {isLoading && (
        <div className="flex-1 flex items-center justify-center p-6">
          <div className="text-center">
            <div className="w-8 h-8 border-2 border-openai-green border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-cool-grey">Generating response...</p>
          </div>
        </div>
      )}

      {/* Search Input Area */}
      <div className="sticky bottom-0 bg-white border-t border-gray-200 p-6">
        <div className="max-w-4xl mx-auto">
          <div className="relative">
            <div className="flex items-end space-x-4">
              <div className="flex-1 relative">
                <textarea
                  ref={textareaRef}
                  value={query}
                  onChange={handleInputChange}
                  onKeyDown={handleKeyDown}
                  placeholder="Ask me anything..."
                  className="w-full min-h-[56px] max-h-32 p-4 pr-12 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-openai-green focus:border-transparent resize-none bg-light-grey placeholder-cool-grey"
                  rows={1}
                  disabled={isLoading}
                />
                <button
                  onClick={() => handleSubmit()}
                  disabled={!query.trim() || isLoading}
                  className="absolute right-3 bottom-3 w-8 h-8 bg-openai-green text-white rounded-lg hover:bg-green-600 transition-colors flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                  </svg>
                </button>
              </div>
            </div>
            
            {/* Input Footer */}
            <div className="flex items-center justify-between mt-3 text-xs text-cool-grey">
              <div className="flex items-center space-x-4">
                <span>Press Enter to send, Shift+Enter for new line</span>
              </div>
              <div className="flex items-center space-x-2">
                <span>Powered by</span>
                <svg className="w-3 h-3 text-openai-green" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                </svg>
                <span>GPT-4</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
