import { Search } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";
import { useToast } from "@/hooks/use-toast";

interface SearchResultsProps {
  search: Search | null;
  isLoading: boolean;
}

export default function SearchResults({ search, isLoading }: SearchResultsProps) {
  const { toast } = useToast();

  const handleCopy = async () => {
    if (!search?.response) return;
    
    try {
      await navigator.clipboard.writeText(search.response);
      toast({
        title: "Copied!",
        description: "Response copied to clipboard",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to copy to clipboard",
        variant: "destructive",
      });
    }
  };

  const handleShare = async () => {
    if (!search) return;
    
    try {
      if (navigator.share) {
        await navigator.share({
          title: search.query,
          text: search.response,
        });
      } else {
        await navigator.clipboard.writeText(`Q: ${search.query}\n\nA: ${search.response}`);
        toast({
          title: "Copied!",
          description: "Search copied to clipboard for sharing",
        });
      }
    } catch (error) {
      toast({
        title: "Error", 
        description: "Failed to share",
        variant: "destructive",
      });
    }
  };

  if (!search) return null;

  return (
    <div className="flex-1 p-6 max-w-4xl mx-auto w-full">
      <div className="space-y-6">
        {/* User Query */}
        <div className="flex justify-end">
          <div className="bg-openai-green text-white p-4 rounded-2xl rounded-br-md max-w-3xl">
            <p>{search.query}</p>
          </div>
        </div>

        {/* AI Response */}
        <div className="flex items-start space-x-4">
          <div className="w-8 h-8 bg-openai-green rounded-full flex items-center justify-center flex-shrink-0">
            <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
            </svg>
          </div>
          <div className="flex-1">
            <div className="bg-light-grey p-6 rounded-2xl rounded-tl-md">
              <div className="prose prose-sm max-w-none text-near-black">
                {search.response.split('\n').map((paragraph, index) => {
                  if (paragraph.trim() === '') return <br key={index} />;
                  
                  // Handle headings
                  if (paragraph.startsWith('## ')) {
                    return <h3 key={index} className="font-semibold text-near-black mt-4 mb-2">{paragraph.slice(3)}</h3>;
                  }
                  if (paragraph.startsWith('# ')) {
                    return <h2 key={index} className="font-bold text-near-black mt-4 mb-2 text-lg">{paragraph.slice(2)}</h2>;
                  }
                  
                  // Handle bullet points
                  if (paragraph.startsWith('- ') || paragraph.startsWith('* ')) {
                    return <li key={index} className="ml-4 mb-1">{paragraph.slice(2)}</li>;
                  }
                  
                  // Regular paragraphs
                  return <p key={index} className="mb-4 last:mb-0">{paragraph}</p>;
                })}
              </div>
            </div>
            <div className="flex items-center justify-between mt-3">
              <div className="flex items-center space-x-4">
                <button className="flex items-center space-x-2 text-cool-grey hover:text-near-black transition-colors">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 10h4.764a2 2 0 011.789 2.894l-3.5 7A2 2 0 0115.263 21h-4.017c-.163 0-.326-.02-.485-.06L7 20m7-10V5a2 2 0 00-2-2h-.095c-.5 0-.905.405-.905.905 0 .714-.211 1.412-.608 2.006L7 11v9m7-10h-2M7 20H5a2 2 0 01-2-2v-6a2 2 0 012-2h2.5" />
                  </svg>
                  <span className="text-sm">Helpful</span>
                </button>
                <button 
                  onClick={handleCopy}
                  className="flex items-center space-x-2 text-cool-grey hover:text-near-black transition-colors"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                  </svg>
                  <span className="text-sm">Copy</span>
                </button>
                <button 
                  onClick={handleShare}
                  className="flex items-center space-x-2 text-cool-grey hover:text-near-black transition-colors"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.367 2.684 3 3 0 00-5.367-2.684z" />
                  </svg>
                  <span className="text-sm">Share</span>
                </button>
              </div>
              <div className="text-xs text-cool-grey">
                {formatDistanceToNow(new Date(search.createdAt), { addSuffix: true })}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
