import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Search, InsertSearch } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export function useSearch() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const searchMutation = useMutation({
    mutationFn: async (data: InsertSearch): Promise<Search> => {
      const response = await apiRequest("POST", "/api/search", data);
      return response.json();
    },
    onSuccess: (newSearch) => {
      // Invalidate and refetch searches
      queryClient.invalidateQueries({ queryKey: ["/api/searches"] });
      
      toast({
        title: "Search completed!",
        description: "Your AI response is ready.",
      });
    },
    onError: (error) => {
      console.error("Search failed:", error);
      toast({
        title: "Search failed",
        description: error instanceof Error ? error.message : "An error occurred while processing your search.",
        variant: "destructive",
      });
    },
  });

  return {
    searchMutation,
    isLoading: searchMutation.isPending,
  };
}
