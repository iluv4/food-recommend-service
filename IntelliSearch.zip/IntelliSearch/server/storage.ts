import { users, searches, type User, type InsertUser, type Search, type InsertSearch } from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  createSearch(search: InsertSearch): Promise<Search>;
  getRecentSearches(limit?: number): Promise<Search[]>;
  getSearchById(id: number): Promise<Search | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private searches: Map<number, Search>;
  private currentUserId: number;
  private currentSearchId: number;

  constructor() {
    this.users = new Map();
    this.searches = new Map();
    this.currentUserId = 1;
    this.currentSearchId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createSearch(insertSearch: InsertSearch): Promise<Search> {
    const id = this.currentSearchId++;
    const search: Search = { 
      ...insertSearch, 
      id, 
      createdAt: new Date() 
    };
    this.searches.set(id, search);
    return search;
  }

  async getRecentSearches(limit: number = 50): Promise<Search[]> {
    const allSearches = Array.from(this.searches.values());
    return allSearches
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      .slice(0, limit);
  }

  async getSearchById(id: number): Promise<Search | undefined> {
    return this.searches.get(id);
  }
}

export const storage = new MemStorage();
