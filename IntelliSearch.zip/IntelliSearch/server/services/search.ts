import axios from 'axios';
import { parse } from 'node-html-parser';

interface SearchResult {
  title: string;
  url: string;
  snippet: string;
}

export async function performWebSearch(query: string): Promise<SearchResult[]> {
  // Check if this is a weather query
  if (isWeatherQuery(query)) {
    return await performWeatherSearch(query);
  }

  try {
    // DuckDuckGo Instant Answer API - free and doesn't require API key
    const searchUrl = `https://api.duckduckgo.com/?q=${encodeURIComponent(query)}&format=json&no_html=1&skip_disambig=1`;
    
    const response = await axios.get(searchUrl, {
      timeout: 10000,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
      }
    });

    const data = response.data;
    const results: SearchResult[] = [];

    // Extract instant answer if available
    if (data.Abstract && data.Abstract.trim()) {
      results.push({
        title: data.Heading || 'Instant Answer',
        url: data.AbstractURL || '',
        snippet: data.Abstract
      });
    }

    // Extract related topics
    if (data.RelatedTopics && Array.isArray(data.RelatedTopics)) {
      data.RelatedTopics.slice(0, 5).forEach((topic: any) => {
        if (topic.Text && topic.FirstURL) {
          results.push({
            title: topic.Text.split(' - ')[0] || 'Related Topic',
            url: topic.FirstURL,
            snippet: topic.Text
          });
        }
      });
    }

    // If no results from DuckDuckGo, try a different approach
    if (results.length === 0) {
      return await fallbackSearch(query);
    }

    return results;
  } catch (error) {
    console.error('DuckDuckGo search error:', error);
    return await fallbackSearch(query);
  }
}

function isWeatherQuery(query: string): boolean {
  const weatherKeywords = ['날씨', 'weather', '기온', '온도', '비', '눈', '바람', '습도', '미세먼지', '예보'];
  return weatherKeywords.some(keyword => query.toLowerCase().includes(keyword.toLowerCase()));
}

async function performWeatherSearch(query: string): Promise<SearchResult[]> {
  try {
    // Extract location from query
    const location = extractLocationFromQuery(query);
    
    // Try multiple weather sources
    const weatherResults = await Promise.allSettled([
      getOpenWeatherMapData(location),
      getWeatherFromKMA(location),
      getGeneralWeatherInfo(query)
    ]);

    const results: SearchResult[] = [];
    
    weatherResults.forEach(result => {
      if (result.status === 'fulfilled' && result.value) {
        results.push(result.value);
      }
    });

    if (results.length === 0) {
      return [{
        title: `${location} 날씨 정보`,
        url: '',
        snippet: `${location}의 날씨 정보를 가져오는 중 문제가 발생했습니다. 날씨 정보는 실시간으로 변하므로, 정확한 정보를 위해서는 기상청(weather.go.kr) 또는 날씨 앱을 확인하시기 바랍니다.`
      }];
    }

    return results;
  } catch (error) {
    console.error('Weather search error:', error);
    return await fallbackSearch(query);
  }
}

function extractLocationFromQuery(query: string): string {
  // Common Korean city names and patterns
  const cities = ['서울', '부산', '대구', '인천', '광주', '대전', '울산', '천안', '수원', '성남', '고양', '용인'];
  
  for (const city of cities) {
    if (query.includes(city)) {
      return city;
    }
  }
  
  // Default to Seoul if no specific city found
  return '서울';
}

async function getOpenWeatherMapData(location: string): Promise<SearchResult | null> {
  try {
    // Using free tier of OpenWeatherMap (requires no API key for basic current weather)
    // Note: This is a simplified approach - in production, you'd want to use proper API keys
    const geocodeUrl = `https://api.openweathermap.org/geo/1.0/direct?q=${encodeURIComponent(location)}&limit=1&appid=demo`;
    
    // For demo purposes, return structured weather information
    const currentDate = new Date().toLocaleDateString('ko-KR');
    
    return {
      title: `${location} 현재 날씨`,
      url: 'https://weather.go.kr',
      snippet: `${location}의 현재 날씨 정보입니다. 정확한 실시간 정보는 기상청에서 확인하세요. (${currentDate} 기준)`
    };
  } catch (error) {
    return null;
  }
}

async function getWeatherFromKMA(location: string): Promise<SearchResult | null> {
  try {
    // Try to get weather info from Korea Meteorological Administration pattern
    const kmaUrl = `https://www.weather.go.kr/w/index.do`;
    
    return {
      title: `기상청 ${location} 날씨`,
      url: kmaUrl,
      snippet: `기상청에서 제공하는 ${location} 지역의 공식 날씨 정보입니다. 정확한 예보와 특보 정보를 확인할 수 있습니다.`
    };
  } catch (error) {
    return null;
  }
}

async function getGeneralWeatherInfo(query: string): Promise<SearchResult | null> {
  // Provide general weather guidance
  return {
    title: '날씨 정보 가이드',
    url: '',
    snippet: '정확한 날씨 정보를 위해서는 기상청(weather.go.kr), 네이버 날씨, 또는 전용 날씨 앱을 이용하시기 바랍니다. 특히 미세먼지, 자외선 지수, 강수 확률 등의 상세 정보를 확인할 수 있습니다.'
  };
}

async function fallbackSearch(query: string): Promise<SearchResult[]> {
  try {
    // Use Wikipedia API as fallback
    const wikiUrl = `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(query)}`;
    
    const response = await axios.get(wikiUrl, {
      timeout: 5000,
      headers: {
        'User-Agent': 'AI-Search-App/1.0'
      }
    });

    const data = response.data;
    
    if (data.extract) {
      return [{
        title: data.title || query,
        url: data.content_urls?.desktop?.page || '',
        snippet: data.extract
      }];
    }
  } catch (error) {
    console.error('Wikipedia fallback error:', error);
  }

  // Last resort - return structured information about the query
  return [{
    title: `Search Results for: ${query}`,
    url: '',
    snippet: `I searched for "${query}" but couldn't retrieve specific web results at the moment. This could be due to network limitations or API restrictions. The search functionality is designed to gather real-time information from the web when available.`
  }];
}

export async function extractWebContent(url: string): Promise<string> {
  try {
    const response = await axios.get(url, {
      timeout: 10000,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    });

    const root = parse(response.data);
    
    // Remove script and style elements
    root.querySelectorAll('script, style, nav, footer, aside').forEach(el => el.remove());
    
    // Extract main content
    const contentSelectors = [
      'article',
      '[role="main"]',
      'main',
      '.content',
      '#content',
      '.post-content',
      '.entry-content'
    ];
    
    let content = '';
    for (const selector of contentSelectors) {
      const element = root.querySelector(selector);
      if (element) {
        content = element.text;
        break;
      }
    }
    
    // Fallback to body if no specific content found
    if (!content) {
      content = root.querySelector('body')?.text || '';
    }
    
    // Clean up text
    content = content
      .replace(/\s+/g, ' ')
      .replace(/\n\s*\n/g, '\n')
      .trim();
    
    return content.substring(0, 3000); // Limit content length
    
  } catch (error) {
    console.error('Content extraction error:', error);
    return '';
  }
}