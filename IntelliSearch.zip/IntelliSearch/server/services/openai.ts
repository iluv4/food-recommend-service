import OpenAI from "openai";
import { performWebSearch, extractWebContent } from "./search";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key"
});

export async function generateSearchResponse(query: string): Promise<string> {
  try {
    // OpenAI's ChatGPT model with web browsing capability
    // Using the model that has access to current information
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `You are a helpful AI assistant that can browse the web for current information. When users ask questions that require up-to-date information, search the web and provide comprehensive, well-structured answers. 

Format your responses with:
- Clear headings using ## or ###
- Bullet points for lists
- **Bold text** for emphasis
- Source citations when available

Always provide the most current and accurate information available from your web search capabilities.`
        },
        {
          role: "user",
          content: query
        }
      ],
      max_tokens: 2000,
      temperature: 0.7,
    });

    const content = response.choices[0].message.content;
    
    if (content) {
      return content;
    } else {
      return "죄송합니다. 검색 결과를 생성할 수 없었습니다. 다시 시도해 주세요.";
    }
    
  } catch (error) {
    console.error("OpenAI API Error:", error);
    
    // If quota exceeded, provide fallback response
    if (error instanceof Error && (error.message.includes('quota') || error.message.includes('429'))) {
      return await generateSearchBasedResponse(query);
    }
    
    // For other errors, provide informative message
    return `검색 중 오류가 발생했습니다: ${error instanceof Error ? error.message : '알 수 없는 오류'}`;
  }
}

async function generateSearchBasedResponse(query: string): Promise<string> {
  try {
    // Get search results even without AI processing
    const searchResults = await performWebSearch(query);
    
    if (searchResults.length === 0) {
      return `# Search Results for: "${query}"\n\nI searched for information about your query but couldn't retrieve specific results at the moment. This could be due to network limitations or the specific nature of your search terms.`;
    }

    let response = `# Search Results for: "${query}"\n\n`;
    response += `Found ${searchResults.length} result(s):\n\n`;
    
    searchResults.forEach((result, index) => {
      response += `## ${index + 1}. ${result.title}\n\n`;
      if (result.url) {
        response += `**Source:** ${result.url}\n\n`;
      }
      response += `${result.snippet}\n\n`;
      response += `---\n\n`;
    });
    
    response += `*Note: These results are from web search. For more detailed analysis, please ensure your OpenAI API quota is available.*`;
    
    return response;
  } catch (error) {
    console.error("Search-based response error:", error);
    return generateDemoResponse(query);
  }
}

function generateDemoResponse(query: string): string {
  const demoResponses = {
    default: `# Demo Response for: "${query}"

Thank you for trying the AI Search application! This is a demo response because the OpenAI API quota has been reached.

## Key Features Demonstrated:
- **Real-time AI Processing**: The application successfully processes your query
- **Formatted Responses**: Responses include proper formatting with headings and bullet points
- **Search History**: Your searches are saved and accessible in the sidebar
- **Interactive UI**: Clean, responsive interface inspired by ChatGPT

## What This Application Can Do:
- Answer complex questions across various topics
- Provide structured, well-formatted responses
- Maintain conversation history
- Support copy and share functionality
- Responsive design for all devices

## Next Steps:
To enable full AI functionality, ensure your OpenAI API key has sufficient quota. The application architecture is ready to handle real GPT-4 responses once the API access is restored.

*This is a demo response. With proper API access, you would receive comprehensive, AI-generated answers tailored to your specific questions.*`,
    
    coding: `# Code Review and Optimization

## Analysis of Your Request
Your query about coding suggests you're looking for technical assistance. Here's what this AI search application excels at:

## Programming Languages Supported:
- **JavaScript/TypeScript**: Full-stack development, React, Node.js
- **Python**: Data science, web development, automation
- **Java**: Enterprise applications, Spring framework
- **C++**: System programming, performance optimization

## Code Review Process:
1. **Syntax Analysis**: Check for proper syntax and structure
2. **Performance Review**: Identify bottlenecks and optimization opportunities  
3. **Best Practices**: Ensure code follows industry standards
4. **Security Assessment**: Review for potential vulnerabilities

## Optimization Strategies:
- Algorithm efficiency improvements
- Memory usage optimization
- Code readability enhancements
- Performance profiling recommendations

*Demo response - actual AI would provide specific code analysis based on your exact query.*`,
    
    explain: `# Complex Concept Explanation

## Breaking Down Complex Topics
This AI search application specializes in making difficult concepts accessible and understandable.

## Explanation Methodology:
1. **Start Simple**: Begin with basic definitions and core principles
2. **Build Gradually**: Layer on complexity step by step
3. **Use Analogies**: Connect abstract concepts to familiar examples
4. **Visual Learning**: Suggest diagrams and visual aids when helpful

## Example Explanations Available:
- **Quantum Computing**: Quantum bits, superposition, entanglement
- **Machine Learning**: Neural networks, algorithms, training processes
- **Blockchain**: Distributed ledgers, consensus mechanisms, cryptocurrencies
- **Cloud Computing**: Infrastructure, services, deployment models

## Learning Support Features:
- Multiple explanation approaches
- Follow-up question suggestions
- Related topic recommendations
- Practical application examples

*This demo shows the application's capability to structure educational content effectively.*`
  };

  // Simple keyword matching for demo purposes
  const lowerQuery = query.toLowerCase();
  if (lowerQuery.includes('code') || lowerQuery.includes('program') || lowerQuery.includes('javascript') || lowerQuery.includes('python')) {
    return demoResponses.coding;
  } else if (lowerQuery.includes('explain') || lowerQuery.includes('what is') || lowerQuery.includes('how does')) {
    return demoResponses.explain;
  } else {
    return demoResponses.default;
  }
}
