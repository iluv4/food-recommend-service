import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { generateSearchResponse } from "./services/openai";

export async function registerRoutes(app: Express): Promise<Server> {
  // Search endpoint
  app.post("/api/search", async (req, res) => {
    try {
      const { query } = req.body;
      
      if (!query || typeof query !== 'string' || query.trim().length === 0) {
        return res.status(400).json({ message: "Query is required" });
      }

      // Generate AI response
      const response = await generateSearchResponse(query.trim());
      
      // Save search to storage
      const search = await storage.createSearch({ query: query.trim(), response });
      
      res.json(search);
    } catch (error) {
      console.error("Search error:", error);
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to process search" 
      });
    }
  });

  // Get search history
  app.get("/api/searches", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      const searches = await storage.getRecentSearches(limit);
      res.json(searches);
    } catch (error) {
      console.error("Get searches error:", error);
      res.status(500).json({ message: "Failed to fetch search history" });
    }
  });

  // Get specific search
  app.get("/api/searches/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const search = await storage.getSearchById(id);
      
      if (!search) {
        return res.status(404).json({ message: "Search not found" });
      }
      
      res.json(search);
    } catch (error) {
      console.error("Get search error:", error);
      res.status(500).json({ message: "Failed to fetch search" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
